1, "Code" folder contains a matlab code and the same matlab code saved as text file

2, "log" folder contains the output of my matlab code

3, "iterates_csv" folder contains the 4 iteration value of my code thetalist

4, "CoppeliaSim Video" folder contains the simulation using the Iterates.csv file

5, "Screenshot_UR5" folder contains the screenshot of the desired endeffector position